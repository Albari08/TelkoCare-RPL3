 <header class="px-10 py-4 bg-white  ">
            <nav class="flex items-center justify-end gap-5">
                <div>
                    <svg class="w-5" viewBox="0 0 34 39" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path class="fill-[#FF0000] hover:fill-[#FF0000]/50"
                            d="M17.0007 38.7917C19.2923 38.7917 21.1673 37.0105 21.1673 34.8334H12.834C12.834 37.0105 14.709 38.7917 17.0007 38.7917ZM29.5007 26.9167V17.0209C29.5007 10.9449 26.1048 5.85841 20.1257 4.51258V3.16675C20.1257 1.52404 18.7298 0.197998 17.0007 0.197998C15.2715 0.197998 13.8757 1.52404 13.8757 3.16675V4.51258C7.91732 5.85841 4.50065 10.9251 4.50065 17.0209V26.9167L0.333984 30.8751V32.8542H33.6673V30.8751L29.5007 26.9167ZM25.334 28.8959H8.66732V17.0209C8.66732 12.1126 11.8132 8.11466 17.0007 8.11466C22.1882 8.11466 25.334 12.1126 25.334 17.0209V28.8959Z" />
                    </svg>
                </div>
                <div><img src="<?php echo e(asset('asset/img/admin.png')); ?>" alt="admin" class="w-8"></div>
            </nav>
        </header><?php /**PATH D:\Thahirudin\Project\TelcoCare3\resources\views/layout/admin/navbar.blade.php ENDPATH**/ ?>