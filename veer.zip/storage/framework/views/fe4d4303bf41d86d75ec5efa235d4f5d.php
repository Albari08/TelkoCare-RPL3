
<?php $__env->startSection('title-page'); ?>
    Antrian
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu-antrian'); ?>
    activemenu
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="px-10 mb-4 border-b border-[#FFF5F5] dark:border-gray-700">
            <ul class="flex flex-wrap -mb-px text-sm font-medium text-center" id="default-styled-tab">
                <li class="me-2" role="presentation">
                    <a href="<?php echo e(route('admin.antrian')); ?>"
                        class="inline-block p-2 rounded-t-lg text-[#FF0000]/50 border-[#FFF5F5] hover:text-[#FF0000] hover:border-[#FF0000] border-b-2">Antrian
                        Aktif</a>
                </li>
                <li class="me-2" role="presentation">
                    <button
                        class="inline-block p-2 rounded-t-lg text-[#FF0000] border-b-2 hover:text-[#FF0000] border-[#FF0000]">Detail</button>
                </li>
            </ul>`
        </div>
        <div class=" w-[80%] mx-auto">
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('admin-antrian.store', ['id' => $antriandetail->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="mb-5" hidden>
                    <label for="id" class="block mb-2 text-2xl font-bold">ID</label>
                    <input type="text" name="id" id="id"
                        class="text-sm p-2 rounded-xl border-[#FF0000] w-full block" value="<?php echo e($antriandetail->id); ?>"
                        placeholder="Silahkan Masukkan Id">
                </div>
                <div class="mb-5">
                    <label for="nama" class="block mb-2 text-2xl font-bold">Nama Lengkap</label>
                    <input type="text" name="nama" id="nama"
                        class="text-sm p-2 rounded-xl border-[#FF0000] w-full block"
                        value="<?php echo e($antriandetail->user->nama); ?>" placeholder="Silahkan Masukkan Nama" disabled>
                </div>
                <div class="mb-5">
                    <label for="email" class="block mb-2 text-2xl font-bold">Email</label>
                    <input type="email" name="email" id="email"
                        class="text-sm p-2 rounded-xl border-[#FF0000] w-full block"
                        value="<?php echo e($antriandetail->user->email); ?>" placeholder="Silahkan Masukkan Email" disabled>
                </div>
                <div class="mb-5">
                    <label for="tanggal" class="block mb-2 text-2xl font-bold">Tanggal Antrian</label>
                    <input type="date" name="tanggal" id="tanggal"
                        class="text-sm p-2 rounded-xl border-[#FF0000] w-full block"
                        value="<?php echo e(\Carbon\Carbon::parse($antriandetail->waktu_antrian)->isoFormat('YYYY-MM-DD')); ?>">
                </div>
                <div class="mb-5">
                    <label for="waktu" class="block mb-2 text-2xl font-bold">Waktu Antrian</label>
                    <input type="time" name="waktu" id="waktu"
                        class="text-sm p-2 rounded-xl border-[#FF0000] w-full block"
                        value="<?php echo e(\Carbon\Carbon::parse($antriandetail->waktu_antrian)->isoFormat('HH:mm')); ?>">
                </div>
                <div class="mb-5">
                    <label for="ruang" class="block mb-2 text-2xl font-bold">Ruang Antrian</label>
                    <input type="text" name="ruang" id="ruang"
                        class="text-sm p-2 rounded-xl border-[#FF0000] w-full block"
                        value="<?php echo e($antriandetail->ruang_antrian); ?>" placeholder="Silahkan Masukkan Ruangan">
                </div>
                <div class="mb-5">
                    <label for="nomor" class="block mb-2 text-2xl font-bold">Nomor Antrian</label>
                    <input type="number" name="nomor" id="nomor"
                        class="text-sm p-2 rounded-xl border-[#FF0000] w-full block"
                        value="<?php echo e($antriandetail->nomor_antrian); ?>" placeholder="Silahkan Masukkan Nomor">
                </div>
                <div class="mb-5">
                    <label for="loket" class="block mb-2 text-2xl font-bold">Loket</label>
                    <input type="number" name="loket" id="loket"
                        class="text-sm p-2 rounded-xl border-[#FF0000] w-full block"
                        value="<?php echo e($antriandetail->loket); ?>" placeholder="Silahkan Masukkan Loket">
                </div>
                <div class="mb-5">
                    <button type="submit"
                        class="px-4 py-2 rounded-md bg-[#FF0000] text-white text-sm hover:bg-[#FF0000]/50 duration-500">Simpan</button>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Thahirudin\Project\TelcoCare3\resources\views/rafly/antrian-admin-detail.blade.php ENDPATH**/ ?>