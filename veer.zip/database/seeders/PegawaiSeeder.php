<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class PegawaiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('pegawais')->insert([
            'nama' => "Admin",
            'alamat' => fake()->address(),
            'email' => "admin@gmail.com",
            'role' => "Admin",
            'password' => Hash::make('password'),
        ]);
        for ($i = 0; $i < 10; $i++) {
            DB::table('pegawais')->insert([
                'nama' => fake()->name(),
                'alamat' => fake()->address(),
                'email' => fake()->email(),
                'role' => "Dokter",
                'password' => Hash::make('password'),
            ]);
        }
    }
}