<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PegawaiController extends Controller
{
    public function showLoginForm()
    {
        return view('login-pegawai');
    }

    public function login(Request $request)
    {
        // kita buat validasi pada saat tombol login di klik
        // validas nya username & password wajib di isi 
        $request->validate([
            'email' => 'required',
            'password' => 'required'
        ]);


        // ambil data request username & password saja 
        $credential = $request->only('email', 'password');

        // cek jika data username dan password valid (sesuai) dengan data
        if (Auth::guard('pegawai')->attempt($credential)) {
            // kalau berhasil simpan data user ya di variabel $user
            $user = Auth::guard('pegawai')->user();
            return redirect()->intended('/admin/antrian');
        }

        // jika ga ada data user yang valid maka kembalikan lagi ke halaman login
// pastikan kirim pesan error juga kalau login gagal ya
        return redirect('login')->withInput()->withErrors(['login_gagal' => 'These credentials does not match our records']);
    }
    public function logout()
    {
        Auth::guard('pegawai')->logout();
        return redirect('/login-pegawai');
    }
}